# Plan template

The plan is the deliverable. It gets read, argued with, and then executed — possibly weeks later, possibly by a different Claude session. Write it so it survives that: specific enough to act on without you in the room.

Adapt the structure to the project. Drop sections that don't apply rather than padding them.

---

## Structure

```markdown
# Redesign plan — <project name>

**Tier:** Polish | Improvement | Revamp
**Scope:** <routes/screens covered>
**Not covered:** <what you couldn't see, e.g. auth-gated routes, and why>
**Preserved (agreed):** <the untouchables from Step 0>

## 1. What this product is

<2–4 sentences. Who uses it, what job they're doing, what "good" means for
them. This exists so every recommendation below can be checked against it.>

**Stack:** <framework, styling, UI library, key deps — as observed>
**Design system maturity:** <tokens exist and are honored / tokens exist but
are bypassed / no tokens>

## 2. App health

<From capture-report.json. Broken routes, console errors, failed requests.
Say plainly if something is broken — the user may care about this more than
the redesign. If everything's clean, one line.>

## 3. Data supply

<Findings from Step 3. If any screen is thin because the data is thin, this
section is the headline of the plan and must come before any styling work.
State the gap concretely: what's fetched vs. what's available, real asset
dimensions vs. what's needed. If the data is fine, say so in one line — it's
useful confirmation.>

## 4. Current state — what's working

<Genuinely. Not flattery, and not empty. Something in here works and should
survive; naming it proves you looked, and tells the user what you won't
break.>

## 5. Findings

### Pain points raised

<Every complaint from Step 0, in the user's own words, and where it lands.
Nothing may silently vanish — an unaddressed pain point is a decision, so
state it as one. Where your diagnosis differs from the fix they implied, the
Diagnosis column is where you say so.>

| # | What they said | Diagnosis | Addressed in |
|---|---|---|---|
| P1 | "the sidebar is unusable on my laptop" | nav collapses at 1280px; their screen is 1366px | F3 · Phase 1 |
| P2 | "make the cards bigger" | cards aren't small, they're empty — 3 fields, see §3 | F1 · Phase 1 |
| P3 | "loading feels slow" | perceived, not real — no skeletons, so it's blank until data lands | F6 · Phase 2 |
| P4 | "the table is too dense" | deliberate — 40-row scanning is the core job | Not addressed, see §12 |

### Ranked

<By user impact, not by ease of fixing. Findings that explain a pain point
above rank above ones you found yourself. Each finding:>

### F1. <Short title>
**Where:** <route> · <component file> · <screenshot: desktop-light/dashboard.png>
**What:** <the observable fact, with values>
**Impact:** <consequence for the person using it>
**Fix:** <the change, expressed as tokens where the codebase allows>

<Group into themes if there are many. Cap at what's genuinely worth doing —
a list of 40 findings won't be read.>

## 6. Design direction  [Revamp, or Improvement that went through Step 6]

<This documents what you generated in Step 6 — it doesn't invent it fresh.
If you skipped Step 6, skip this section too.>

**Token system:**
- Color: <4-6 named hex values, traced back to what "should feel like" answer>
- Type: <display face + body face, and why this pairing>
- Layout concept: <one sentence + the ASCII wireframe from Step 6>
- Signature element: <the one thing this design is remembered by>

**Mockup:** <link to or embed the artifact/visual produced in Step 6>

**Why this direction fits this product:** <grounded in Step 1's product
understanding, not generic taste>
**What this gives up:** <every direction trades something away. Name it.>
**Directions considered and rejected:** <briefly, if it helps the user trust
the pick — not required>

## 7. Screen-by-screen

<For each significant screen: what changes, what stays, what it should
achieve. For Revamp, describe the new layout concretely enough to build —
regions, hierarchy, what's primary. ASCII layout sketches are fine and often
clearer than prose.>

## 8. Tokens and system changes

<Where the codebase has tokens, put changes here rather than scattering them
through §6 — it's the smallest diff and the most reviewable. Concrete
before/after values.>

| Token | Current | Proposed | Why |
|---|---|---|---|
| `--radius` | 0.5rem | 0.75rem | ... |

## 9. Library and tooling notes

<New dependencies get their own explicit yes/no here — bundled approval of the
plan is not approval of new package surface.>

<Use the four-part suggestion format from library-landscape.md. If nothing
new is needed, say so explicitly — "no new dependencies required" is a
finding the user will be glad to read.>

**Staying as-is:** <incumbents, named, so the user knows you're not
proposing to unpick them>

## 10. Phased plan

<Each phase independently shippable. Phase 1 alone should leave the product
coherent — that's what lets the user stop early.>

### Phase 1 — <name> (<rough effort>)
- [ ] <task, with file paths>

### Phase 2 — <name> (<rough effort>)
...

## 11. Risks and things I'd flag

<Shared components with wide blast radius. Accessibility regressions.
Changes to things users have muscle memory for. Anything where you're
uncertain. For each: what you'd do instead if they don't want the risk.>

## 12. Deliberately left alone

<What you chose not to change, and why. Restraint is a design decision and
its absence is noticeable.>

## 13. Open questions

<Things only the user can answer. Keep it short and answerable — a wall of
questions reads as an unfinished plan.>
```

---

## Tier-specific emphasis

**Polish** — §5 carries the plan. Be exhaustive and exact within a narrow scope; every finding should have an unambiguous fix with specific values. Drop §6 entirely, keep §7 brief, likely one phase.

**Improvement** — balanced. §5 and §8 do the heavy lifting; §7 covers layout-level changes. Two or three phases. Drop §6.

**Revamp** — §6 and §7 carry the plan. §5 shrinks to a functional inventory plus a brief justification of why a revamp rather than an improvement. §12 gets more important, not less: in a full redesign the user most wants to know what you *didn't* throw away.

## Writing notes

- **File paths, not descriptions.** `components/layout/Sidebar.tsx`, not "the sidebar component."
- **Values, not adjectives.** "`p-4` → `p-6`", not "more generous padding."
- **Cite screenshots** so findings are checkable rather than trust-based.
- **Pain points close in every tier.** Even a single-phase Polish plan states where each one landed. It's the first thing the user checks, and the omission they notice fastest.
- **Skimmable.** Headings, short paragraphs, tables. Assume the user reads §1, §3, §5 titles, and §10 first.
- **Own the uncertainty.** "I couldn't tell whether the density on `/invoices` is deliberate — if it is, skip F7" is more useful than false confidence.
- **Effort estimates as ranges** with a note that they're rough. A wrong-but-stated estimate is more useful for prioritizing than none.
