# Library landscape

Deliberately **no version numbers and no rankings** here. This file lists what to consider by category; you check current state before recommending anything. Ecosystems move, packages get deprecated or absorbed, and a confidently stale recommendation costs the user more trust than saying "let me check."

Before recommending: `npm view <pkg> version time.modified`, check the repo's activity, or search. If a package looks abandoned, say so instead of recommending it.

Contents: [The default is no change](#the-default-is-no-change) · [When a swap is justified](#when-a-swap-is-actually-justified) · [Categories](#categories) · [Suggestion format](#how-to-write-the-suggestion) · [Bundle cost](#bundle-cost-reality)

---

## The default is no change

The incumbent UI library stays. The user picked shadcn/ui or MUI or Chakra or raw Tailwind for reasons that aren't visible in the code: familiarity, consistency with their other projects, a team decision, a past migration they don't want to repeat, or simply that it works. Assume deliberate.

Most redesigns need **zero** new dependencies. The redesign lives in tokens, layout, hierarchy, and states. If your plan opens with a dependency list, you've probably mistaken "different" for "better."

## When a swap is actually justified

All three of these should hold. If only two do, it's a note, not a recommendation:

1. **There's concrete pain in this codebase** — a large hand-rolled implementation, a known bug class, a documented performance problem, or the incumbent genuinely can't do something the plan requires.
2. **The win is quantifiable** — lines of code removed, capability gained, measured performance delta. "More modern" and "more cohesive" are not wins.
3. **The migration surface is bounded** — you can name the files affected and it isn't "all of them."

**Additive beats replacement.** Adding a headless table library alongside shadcn is a contained change. Replacing shadcn with Mantine is a rewrite wearing a redesign costume. Reach for additive first, nearly always.

## Categories

Consider these when the plan creates a genuine need. The point is coverage of the option space, not a shopping list.

**Component foundations** — shadcn/ui (Radix + Tailwind, copy-in so fully restylable), Radix Primitives or React Aria or Base UI (headless, you own all styling), MUI / Mantine / Chakra / Ant (batteries-included, opinionated visuals), HeroUI, Park UI. *Only ever relevant if the project has no foundation at all, or the incumbent provably blocks the plan.*

**Styling** — Tailwind, CSS Modules, vanilla-extract, Panda CSS, StyleX, plain CSS with custom properties. Switching styling approach mid-project is expensive and rarely worth it for visual reasons; if tokens are the problem, fix the tokens.

**Tables and data grids** — TanStack Table (headless: sorting, filtering, grouping, pagination, column sizing; you style it), AG Grid (heavyweight, enterprise features, licensing to check), MUI X Data Grid. *Hand-rolled sortable/virtualized tables are the single most common legitimate swap in dashboard redesigns.*

**Virtualization** — TanStack Virtual, react-virtuoso. Justified by real list length (thousands of rows), not by aesthetics.

**Forms** — React Hook Form, TanStack Form, Formik; validation via Zod, Valibot, Yup. Relevant when the redesign reworks form UX (inline validation, multi-step, dirty-state handling) and the current implementation is manual `useState` per field.

**Charts** — Recharts (composable React, easy), Visx (low-level, d3-powered, maximum control), Chart.js, ECharts (very broad chart types), Nivo, Observable Plot, Tremor (dashboard-oriented, Tailwind-native), or raw d3 for bespoke visuals. Match to how custom the visuals need to be — Recharts for standard, Visx/d3 when the design calls for something that doesn't exist off the shelf.

**Animation** — Motion (formerly Framer Motion), React Spring, Auto-Animate (near-zero-config layout transitions), or plain CSS transitions. Most UI motion needs are CSS-sized; pull in a library when you need layout animation, gesture handling, or orchestrated sequences.

**Icons** — Lucide, Phosphor, Radix Icons, Heroicons, Tabler, Iconoir. Consistency of set and weight matters more than which set.

**Type** — variable fonts via `next/font` (self-hosted, no layout shift). Watch for: tabular numerals for anything numeric, sufficient weight range for hierarchy, and non-Latin coverage if relevant.

**Drag and drop** — dnd-kit, Pragmatic drag and drop, react-dnd.

**Date/time** — react-day-picker, plus date-fns / Day.js / Temporal for the logic. Check whether the incumbent library already has a picker before adding one.

**Command palettes and overlays** — cmdk, Vaul (drawers), Sonner (toasts), Radix Dialog/Popover. Small, focused, cheap.

**Rich text** — Tiptap, Lexical, Plate, Slate.

**Layout and dev tooling** — Storybook or Ladle (component review — genuinely useful during a redesign for reviewing states in isolation), Chromatic or Playwright visual comparison (catching regressions when a token change ripples).

## How to write the suggestion

Every suggestion in the plan uses this shape. The final line is what makes it a suggestion the user can decline without unpicking the plan:

```
**Suggestion:** TanStack Table for the invoices grid
**Why now:** InvoiceTable.tsx is ~380 lines of hand-rolled sorting, column
resize, and pagination, and the plan adds column visibility toggles and
grouping — both of which mean extending that code further.
**Cost:** ~14KB gzipped, headless so all current shadcn styling is kept,
migration touches InvoiceTable.tsx and its 3 sub-components only.
**If you'd rather not:** the redesign works as-is; column toggles get built
on the existing implementation, roughly a day more work and the grouping
feature would probably be dropped from Phase 2.
```

## Bundle cost reality

Name the cost, don't hand-wave it. Check actual sizes (bundlephobia, or the package's own docs) rather than guessing. Mention when something is tree-shakeable or headless-and-therefore-small, and mention when it isn't. Users on their own infrastructure care about this, and a suggestion that hides its cost reads as sales rather than advice.
