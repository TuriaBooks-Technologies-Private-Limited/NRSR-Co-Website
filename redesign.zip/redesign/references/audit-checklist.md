# Audit checklist

Contents: [How to use](#how-to-use) · [0. Data supply](#0-data-supply-do-this-first) · [1. Hierarchy](#1-hierarchy-and-first-read) · [2. Typography](#2-typography) · [3. Color](#3-color-and-contrast) · [4. Spacing](#4-spacing-density-and-alignment) · [5. Components](#5-components-and-consistency) · [6. States](#6-states-the-most-skipped-section) · [7. Responsive](#7-responsive-behavior) · [8. Motion](#8-motion) · [9. Accessibility](#9-accessibility) · [10. Code health](#10-design-system-health-code-side) · [Tier depth](#how-deep-to-go-per-tier)

## How to use

Every finding needs three parts, or it isn't usable:

1. **Where** — route, component file, and which screenshot shows it
2. **What** — the observable fact, not the feeling
3. **Why it matters** — the consequence for the person using the product

> Weak: "Typography needs work."
> Usable: "`/dashboard` (desktop-light) uses four font sizes between 13px and 16px across sibling cards — `StatCard.tsx` at `text-sm`, `RecentActivity.tsx` at `text-[13px]`, table cells at `text-base`. The near-identical sizes read as sloppiness rather than hierarchy, and none of them signal which number matters most."

Skip dimensions that don't apply. A marketing page has no density problem; a data table has no hero problem. Note what you skipped so the user knows it was a decision.

---

## 0. Data supply (do this first)

A screen cannot be fixed with CSS if it has nothing to show. Before any visual dimension below, for each component that looks sparse:

- **What fields does it receive?** Trace component → API route → data layer → source.
- **What fields are available but unrequested?** If the source is an external API, read its schema. The gap between "what the API returns" and "what the query asks for" is where sparse UIs usually come from.
- **Are the assets the right size?** Check the actual bytes — `curl` the image and run `file`/`identify` on it, or read `Content-Length`. A field named `large` may be 230px and visibly soft at 2× density. Verify before designing around it, and certainly before writing a query or migration that assumes it.
- **What's absent entirely?** Descriptions, categories, counts, timestamps, relationships, status.

If the answer is "the data is thin," that is the top finding and it outranks everything below. Sequence the data fix *before* the styling in the plan — a design that assumes richer content isn't implementable until the content exists.

## 1. Hierarchy and first read

Squint at the screenshot, or view it small. What do you notice first, second, third?

- Does the visual emphasis match the actual priority of the page's job?
- Is there one clear primary action per screen, or several competing?
- Do headings form a real scale, or are levels distinguished only by weight?
- Is anything important buried — below the fold, in low-contrast text, or styled like chrome?
- Is anything unimportant loud — decorative imagery, a full-color banner around a dismissible notice?

Hierarchy failures are the highest-impact and most commonly missed. If you find one, it usually outranks everything else in the plan.

## 2. Typography

- **Scale**: how many distinct sizes are in use? More than ~6 usually means drift. Sizes within 1–2px of each other create noise, not hierarchy.
- **Line height**: body text below ~1.5 is cramped; headings above ~1.3 look loose.
- **Measure**: body line length beyond ~75 characters is hard to track back.
- **Weight**: is weight doing hierarchy work, or is everything 400/600?
- **Font choice**: does it fit the product? Does it have the weights and numerals actually needed — tabular numerals matter a lot for anything with money or metrics.
- **Alignment**: centered blocks of body text, justified text, mixed alignment within a section.

## 3. Color and contrast

- **Roles**: does each color mean something consistently — primary action, destructive, success, warning, muted? Or is the accent used decoratively in places where it implies interactivity?
- **Contrast**: check body text, muted/secondary text, placeholder text, disabled states, text on colored backgrounds, and icon-only buttons. WCAG AA is 4.5:1 for normal text, 3:1 for large text and non-text UI. Muted text on tinted backgrounds is the usual failure.
- **Semantic-only signals**: is any state conveyed by color alone? Fails for colorblind users.
- **Dark mode** (if present): compare against light. Pure black backgrounds, inverted shadows that vanish, borders that disappear, saturated accents that vibrate on dark, images with baked-in white backgrounds.
- **Content-derived color**: is any color pulled from the content itself (cover art, category, user-chosen tag)? If so, it's a separate system from the app accent and the two must not composite on one element — that produces muddy two-hue blends and reads as a bug. Check whether the boundary is defined anywhere or just implicit.
- **Computed, not eyeballed**: every ratio in your findings should come from `scripts/color.mjs`, not from looking at it.
- **Hardcoded values**: hex codes or `rgb()` in components while tokens exist elsewhere — a maintainability finding as much as a visual one.

## 4. Spacing, density, and alignment

- **Scale adherence**: does spacing follow a scale (4/8px), or arbitrary values?
- **Consistency across screens**: same component type, same padding, on every route?
- **Proximity grouping**: is related content closer together than unrelated content? Uniform spacing everywhere destroys grouping.
- **Density fit**: dense is correct for tools people live in all day; airy is correct for pages people visit once. Mismatch is common in dashboards built from marketing-site instincts.
- **Alignment**: shared left edges, consistent optical alignment of icons with text, form labels and inputs on a grid.
- **Container width and rhythm**: does the layout use the viewport well at 1440px+, or is content stranded in a narrow column with vast empty margins?

## 5. Components and consistency

- **Vocabulary size**: how many button variants, card treatments, badge styles actually exist? More than the design intends = drift.
- **One job, one component**: are there three different card implementations doing the same thing?
- **Border radius, border width, shadow elevation**: consistent, or per-component improvisation?
- **Interactive affordance**: do clickable things look clickable? Do non-clickable things avoid looking clickable?
- **Iconography**: one icon set, one weight, one size scale, consistent optical sizing?
- **Forms**: label placement, required indicators, help text, inline validation, error placement, input heights matching button heights.
- **Tables**: header treatment, row separation, alignment by data type (numbers right, tabular numerals), sort affordances, row actions, sticky headers on long tables.

## 6. States (the most skipped section)

Seeded demo data hides all of these. Check the code for whether they exist at all, and note it as a finding when they don't — because the user will hit them in production.

- **Empty** — first-run vs. filtered-to-nothing are different states with different copy and different actions. Both need a next step, not just "No data."
- **Loading** — skeletons matched to real content shape, or spinner-in-the-middle-of-nothing? Does layout shift when data arrives?
- **Error** — what does a failed fetch look like? Is there a retry? Does the error say what to do?
- **Partial/optimistic** — pending mutations, saving indicators, stale-while-revalidating.
- **Hover / focus-visible / active / disabled** — focus-visible is the one usually missing entirely and it's a keyboard-accessibility failure.
- **Overflow reality** — long names, long emails, 6-digit counts, 40-item lists. Does anything break, truncate badly, or push layout?

## 7. Responsive behavior

Compare mobile and desktop captures of the same route directly.

- Horizontal scroll at any width
- Tables — do they scroll, stack, collapse to cards, or just get cut off?
- Navigation — what happens to the sidebar or nav bar on small screens? Is the collapsed version usable?
- Touch targets — anything under ~44px is hard to hit
- Modals and drawers on small screens — full-height? Scrollable? Dismissible?
- Text reflow — headings breaking awkwardly, orphaned words
- Whether the mobile layout is genuinely designed or just the desktop layout squeezed

## 8. Motion

- Do state changes have any transition, or does everything snap?
- Is anything animating that shouldn't — attention-grabbing motion on routine content?
- Duration sanity: 120–250ms for most UI transitions. Over ~400ms feels sluggish on repeat use.
- Is `prefers-reduced-motion` respected?
- Does motion carry meaning — direction implying hierarchy, origin implying source — or is it decoration?

## 9. Accessibility

Not a separate concern from design; bad accessibility usually shows up as bad design.

- Semantic elements — real `button`, `nav`, `main`, headings in order — vs. `div` soup
- Keyboard path through every interactive element, with a visible focus ring
- Focus management in modals and drawers: trapped, returned on close
- Accessible names for icon-only buttons
- Form labels actually associated with inputs
- Errors announced, not just colored red
- Contrast (see §3)

## 10. Design system health (code side)

This determines how cheap the redesign can be, so it belongs in the audit.

- Do design tokens exist? CSS custom properties, Tailwind theme extension, a theme object?
- **Is the theme machinery actually wired?** A complete `.dark` block proves nothing — the provider may never be mounted, leaving it unreachable dead code. Toggle it in the browser to confirm. Finding a fully-built-but-dead dark mode is a common and very cheap win.
- Are they *used*, or bypassed with hardcoded values?
- Is there a single source of truth for the spacing scale, type scale, radii, shadows?
- Is the component library wrapped (so it can be restyled centrally) or used raw everywhere?
- How many places would a single visual change need to be edited?

A token-disciplined codebase means an ambitious redesign is a small diff. A drifting one means even modest changes are broad, and the plan should probably include a token-consolidation phase first.

---

## How deep to go per tier

- **Polish** — §2–§6 narrowly and precisely. Enumerate specific inconsistencies with exact values. Skip strategic questions; the user isn't asking.
- **Improvement** — everything, weighted toward §1, §4, §5, §6. This is where hierarchy, density, and missing states usually produce the biggest wins.
- **Revamp** — audit mainly as a **functional inventory**: what does each screen do, what data does it show, what actions exist, what states are handled. You need this so the new design doesn't silently drop capability. Log visual findings briefly (they justify the revamp) but don't write a detailed style critique of something you're replacing.
