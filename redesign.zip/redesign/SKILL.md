---
name: redesign
description: Audit and redesign the UI of an existing web project at one of three intensities - full revamp, improvement, or polish. Understands the product from its code and docs, captures the running app with Playwright screenshots, diagnoses whether a sparse screen is a styling problem or a starved-data problem, then generates and shows a new design direction with its own color, type, layout, and signature element. Produces a reviewable plan that respects the libraries already in the codebase while suggesting better-suited ones where the gap is real. Use whenever the user wants to redesign, revamp, refresh, modernize, or overhaul an existing UI, dashboard, landing page, or app - including vaguer asks like "this looks dated", "the design feels off", "come up with a better design for this", or "what would you change about my UI". Also use for a design audit of a running project, for choosing a brand palette or accent color, or when asked which UI libraries suit their stack better.
---

# Redesign

This skill is for redesigning something that **already exists**. That constraint is the whole point. A greenfield design is a blank-page problem; a redesign is an archaeology problem first. Somebody made choices in this codebase — some deliberate, some accidental, some load-bearing in ways that aren't visible from a screenshot. Redesigning well means understanding those choices before overwriting them.

The output is a **written plan the user reviews and discusses with you**. Do not start editing components. The user wants to argue with the plan first, and that argument is where most of the value is.

## The four failure modes to avoid

**Reskinning a starved UI.** The most expensive one, because the work looks finished. If a screen renders 100px thumbnails, no synopsis, and no metadata, no amount of whitespace and typography will fix it — the interface is thin because the *data* is thin. Restyling it produces something prettier and still empty. When a screen looks sparse, underwhelming, or "cheap," the first question is **what data does this component actually have to work with**, not what CSS is applied to it. See Step 3; it exists because this is the diagnosis most redesigns skip and the one that most changes the outcome.

**Generic reskin.** Producing a plan that could have been written for any project — "add more whitespace, use a modern sans-serif, increase contrast, add subtle shadows." This is worthless. It's the design equivalent of "have you tried turning it off and on again." If your plan doesn't reference specific screens, specific components, and specific things about *this* product's users and jobs-to-be-done, throw it away and go back to Step 1.

**Rewriting by suggestion.** Deciding the project should be on a different UI library and quietly building the plan on that assumption. The user may have picked shadcn/ui, MUI, Chakra, or hand-rolled Tailwind for reasons they don't feel like re-litigating. Incumbent libraries are the default and stay the default. See "Library policy" below — it's the part of this skill most likely to annoy the user if you get it wrong.

**Fixing the wrong problem beautifully.** The user told you what bothers them, and the plan addresses everything except that. It's the failure they notice fastest, and it makes an otherwise well-evidenced document feel like it was written about somebody else's product. Every pain point they raise gets tracked through to a resolution — or to an explicit, reasoned "not this time." Silence on a stated complaint reads as not having listened. See Step 0.

---

## Step 0 — Set the intensity and the untouchables

Before any analysis, establish the ground rules with the user — the tier, the untouchables, what's wrong today, and what it should feel like. Ask directly; don't guess. If they've already said which tier they want, skip to confirming untouchables.

**The three tiers:**

| Tier | What it means | Design starts from |
|---|---|---|
| **Polish** | Fix what's visibly broken or inconsistent. Nothing moves. | The existing design, corrected |
| **Improvement** | Same information architecture and component vocabulary, meaningfully better execution. Layouts can shift, components can be restyled or consolidated. | The existing design, elevated |
| **Revamp** | A new design. Not derived from the current one. | The product's purpose, from scratch |

The tier changes what you're *allowed to question*, not how hard you try:

- **Polish** — accept the layout, the hierarchy, the component set, the visual language. You're fixing spacing drift, inconsistent radii, misaligned elements, contrast failures, ragged responsive behavior, hover/focus states that don't exist. High-confidence, low-risk, small diffs.
- **Improvement** — accept the IA (what pages exist, what's on them, what the user does) but question the execution. Density, typographic scale, color roles, component consistency, empty/loading/error states, motion. You may propose merging or splitting components, changing a layout from cards to a table, reworking navigation *chrome* — but not renaming or relocating the pages themselves.
- **Revamp** — question everything except the product's purpose and the untouchables. Deliberately do **not** anchor on the current design. This matters: if you look at the existing dashboard and then "redesign" it, you'll produce the existing dashboard with rounder corners. Instead, work forward from what the product is *for* (Step 1) and design as if the current version didn't exist. Look at the screenshots afterward, to check you haven't dropped functionality — not before, as a starting point.

**Untouchables.** Ask what must survive regardless of tier. People almost always have some: a logo, a brand color, a specific interaction they're proud of, a component another team depends on, a layout users have muscle memory for. In a Revamp especially, ask explicitly — "full redesign" rarely means *actually* everything. Write the answer down in the plan so it's checkable.

**Ask what's actually wrong today.** The tier tells you how far you're allowed to go; this tells you what the work is *for*. Ask plainly — *"What specifically bothers you about it right now?"* — and record the answers **verbatim**, numbered P1, P2, P3. Verbatim matters: paraphrasing a complaint quietly converts it into your reading of the complaint, and your reading is then what the plan solves.

Two rules for handling them:

- **They're symptoms, not work orders.** People name a fix ("make the cards bigger") when what they've actually noticed is a problem ("this screen feels empty"). Diagnose the cause the way Step 3 does for sparse screens. If your diagnosis lands somewhere other than the fix they named, say so and explain why — a plan that dutifully enlarges the cards when the real problem is three fields of data has followed instructions and failed the person.
- **They outrank anything you find yourself.** You're inferring from screenshots; they've been using this daily. When a stated pain point and an audit finding compete for a place in Phase 1, the stated one wins unless you can say why not.

**Ask what it should feel like — before proposing any color.** This is a specific, repeatedly-learned lesson: left to itself, the safe default is a generic indigo/blue and a neutral corporate palette, which gets rejected and rebuilt. Two questions prevent that round trip:

- *"What should this feel like to use?"* — adjectives are fine and useful. Sharp, calm, playful, dense, cinematic, utilitarian, warm.
- *"Any colors or references you're drawn to, or actively don't want?"*

The product category usually already answers this and you should notice when it does. A manga tracker, a game tool, a music app, a kids' product — none of these have any reason to look like B2B SaaS, and defaulting them to blue is a failure of attention, not a neutral choice. If you find yourself proposing a hue because it's safe, stop and ask instead.

If the user is vague about tier ("just make it better"), show them the table and let them pick. Guessing wrong here wastes the entire analysis.

---

## Step 1 — Understand the product

You cannot critique a design without knowing what it's for. A dense data table is wrong for a marketing site and right for an accounting ledger. Spend real effort here; it's what separates this skill from a generic style opinion.

Read, in roughly this order, stopping when you have a confident picture:

1. **`README.md`, `docs/`, `CLAUDE.md`, `AGENTS.md`, any PRD or design docs.** Fastest route to intent. `CLAUDE.md` in particular often encodes conventions the user cares about.
2. **`package.json`** — framework, version, UI libraries, styling approach, state management, form/table/chart/animation libraries, icon set. Also the scripts, so you know how to run it.
3. **Route structure** — `app/`, `pages/`, or the router config. This *is* the information architecture. Use `scripts/discover-routes.mjs` for Next.js (App or Pages router); it handles route groups, dynamic segments, and private folders correctly.

   Scope this pass to **page-rendering routes and `lib/`**. Cataloguing every API route — auth, webhooks, cron, health — is noise you will never use; the script separates them for you. Come back for a specific API route only when a screen's data raises a question about it.
4. **The design system, if there is one** — `tailwind.config`, `globals.css`, theme files, `components/ui/`. Look for CSS custom properties, token naming, existing theme/dark-mode machinery. If tokens exist, the redesign should be expressible *as token changes* wherever possible — that's a far smaller diff than editing components.
5. **The data models** — Prisma schema, API types, DB migrations. What entities exist tells you what screens genuinely need to show. This is where you find the density requirements the screenshots only hint at.
6. **A representative slice of components** — the layout shell, nav, one or two of the most complex screens. Enough to know whether the codebase is disciplined or drifting.

Then write, for yourself and later for the plan, a short honest statement:

- **What this product is** and who uses it (a specific person doing a specific job, not "users").
- **The primary jobs-to-be-done** on the main screens.
- **The current design language** — as it actually is, not as intended.
- **Discipline level** — tokens honored or ad-hoc hex everywhere? Consistent spacing scale or vibes? This sets how ambitious the plan can realistically be.

If the product's purpose stays unclear after reading, ask the user. Two sentences from them beats twenty minutes of inference.

---

## Step 2 — Capture the running app

Screenshots are the ground truth. Reading JSX tells you what was intended; a screenshot tells you what shipped.

**Check whether a dev server is already running before starting one.** Users often have one up already; launching a second wastes time and can bind a different port than the one you then try to screenshot. `curl -sI http://localhost:3000` (or `lsof -i :3000` / `netstat -ano | findstr :3000` on Windows) first, and only start one if nothing answers. Confirm the port before capturing.

Then use the bundled capture script:

```bash
node scripts/capture-ui.mjs \
  --base-url http://localhost:3000 \
  --routes / /dashboard /settings \
  --out ./redesign-audit/screenshots
```

Useful flags: `--routes-file routes.json` (pairs with `discover-routes.mjs`), `--viewports mobile,tablet,desktop`, `--color-scheme light,dark`, `--auth-storage state.json`, `--full-page`. Run `node scripts/capture-ui.mjs --help` for the full list. If Playwright isn't installed, the script prints the exact install command — offer it to the user rather than silently skipping the capture.

**Verify the app actually works.** The script writes `capture-report.json` with per-route HTTP status, console errors, failed network requests, and page title. Read it. A route that 500s or floods the console isn't a design problem, and reporting a redesign for a broken page wastes everyone's time. Surface breakage to the user immediately — it may well be the thing they most want to know.

**Auth-gated apps** are the common blocker. If routes redirect to a login page, ask the user for a way in: seeded dev credentials, a saved Playwright storage state, or a bypass flag. If they can't provide one, say plainly which routes you couldn't see and that the audit is partial for those. A confident critique of pages you never rendered is worse than an honest gap.

Then **look at every screenshot** with the `view` tool. Capturing and viewing are two separate round trips — the script writes PNGs, then you must actually read them. Batch the capture, then batch the reads; don't interleave one route at a time. Not a sample. The inconsistencies you're hunting — the one card with a different radius, the button that's 2px off — only show up under actual inspection.

---

## Step 3 — Diagnose before you critique

Now that you've seen the app, and **before** you write a single style observation: for every screen that looks sparse, thin, cheap, or underwhelming, find out whether the problem is presentation or supply.

Ask of each significant component: **what data does this actually have to work with?**

- Trace the field back — component → API route → data layer → external source. What's fetched, what's stored, what's rendered.
- Compare against what's *available*. If it pulls from an external API, what other fields does that API return that aren't being requested? This gap is where the finding usually is.
- **Check the real bytes, not the field name.** A field called `coverImage.large` tells you nothing about whether it's 230px or 1400px. `curl` the actual asset and inspect it (`file`, `identify`, or check `Content-Length`). Do this *before* writing any query or migration that depends on the assumption — discovering the true dimensions after backfilling means reworking the query, the types, and every write site.
- Check what's missing entirely: descriptions, categories, timestamps, counts, relationships, status. A card with three fields looks thin because it *is* thin.

If the diagnosis comes back "the data is starved," **say so first and loudly**, and make it the top of the plan. A design that assumes richer data is only implementable if the data arrives, so the fix is sequenced before the styling, not alongside it. This reframing — "this isn't a CSS problem" — is frequently the single most valuable output of the whole exercise.

If the data is fine and the presentation is genuinely the problem, say that too, and move on. The point isn't to always find a data issue; it's to never *assume* there isn't one.

## Step 4 — Audit what you see

Work from the screenshots and the code together, and keep evidence attached to every finding. "Spacing is inconsistent" is a complaint; "cards on `/dashboard` use `p-4` while `/settings` uses `p-6`, visible in the 1440px shots" is a finding someone can act on.

`references/audit-checklist.md` has the full dimension-by-dimension checklist — hierarchy, typography, color and contrast, spacing and density, components and states, responsive behavior, motion, accessibility. Read it before auditing; it's easy to focus on color and miss that no screen has an empty state.

Two things worth calling out because they're the most commonly skipped and the most commonly complained about later:

- **The non-happy states.** Empty, loading, error, zero-results, first-run. Real users hit these constantly and screenshots of seeded data hide them entirely. Check the code for whether they exist at all.
- **Responsive reality.** Compare the mobile and desktop shots directly. Tables that scroll off-screen, nav that vanishes, touch targets under ~44px, text that reflows badly.

Rank findings by user impact, not by how easy they are to describe — and rank anything that explains a pain point from Step 0 above findings you discovered yourself. Adjust depth to tier: Polish audits narrowly and precisely; Revamp audits mainly to inventory functionality so nothing gets dropped.

---

## Step 5 — Assess libraries and tooling

The user's question here is "am I missing something better?" — not "should I rewrite everything?" Answer the first one.

### Library policy

**Incumbents win by default.** If the project uses shadcn/ui, the plan is built on shadcn/ui. Same for MUI, Chakra, Mantine, Radix, Ant, or hand-rolled Tailwind. Migration cost is real, the user's familiarity is real, and consistency with their other projects is real — and you can't see any of that from the code. Assume the choice was deliberate.

**Suggest a replacement only when the gap is specific and large.** A legitimate suggestion looks like: *"You're hand-rolling a virtualized table with sorting and column resizing in `DataGrid.tsx` — about 400 lines. TanStack Table handles this and would drop it to roughly 80, with keyboard nav you don't have."* That names the pain, names the tool, and quantifies the win. An illegitimate suggestion looks like: *"Consider migrating to Mantine for a more cohesive design system."* That's taste dressed as engineering.

**Additive suggestions are cheap and usually the real answer.** Most redesigns need a gap filled, not a foundation swapped: a headless table, charts, a date picker, animation, a virtualization layer, better icons, a specific font. These slot in beside the incumbent. Prefer them.

Structure every suggestion so it's easy to decline:

```
**Suggestion:** <library> for <specific need>
**Why now:** <what in this codebase or plan creates the need>
**Cost:** <bundle size, install/config work, learning curve, migration surface>
**If you'd rather not:** <how the plan works without it>
```

That last line is what makes it a suggestion rather than a dependency. Always include it.

In **Revamp**, you have more latitude to propose ambitious tooling — but latitude to *propose*, not to assume. Even here, the incumbent must remain a viable path through the plan. If a Revamp only works with a new library, you've written a rewrite proposal, not a redesign plan.

**Itemize new dependencies; don't bundle them into overall approval.** If the user approves the plan and the plan happens to contain three `npm install`s, that's bundled consent, not a decision they made. New dependency surface — bundle size, maintenance, supply chain — deserves its own yes. List new packages as a distinct, separately-approvable item in the plan, even when the user asked you to recommend libraries.

**Version currency:** library ecosystems move fast and your training data has a cutoff. Before recommending anything, check current state — `npm view <pkg> version`, the library's docs, or a web search. Do not confidently recommend something that's been deprecated, renamed, or superseded. `references/library-landscape.md` lists candidates by category to consider, deliberately without pinning versions.

---

## Color discipline (whenever you propose a palette)

Applies across Steps 4–6, not at one point in the sequence.

**Never eyeball contrast.** It fails at least once per redesign, and you want to know before the user does. Use `scripts/color.mjs` — it holds the oklch ↔ sRGB ↔ WCAG math, correctly linearized. The recurring silent bug is feeding gamma-encoded sRGB straight into the relative-luminance formula: it yields plausible-but-wrong numbers, which is far more dangerous than obviously-wrong ones. Don't rederive this in a scratch script; that's how the bug gets reintroduced.

```bash
node scripts/color.mjs convert  "oklch(0.62 0.19 27)"      # oklch↔hex, gamut check
node scripts/color.mjs contrast "#d94a2b" "#ffffff"        # WCAG + AA/AAA verdicts
node scripts/color.mjs solve    "#ffffff" 4.5 --hue 27 --chroma 0.19
node scripts/color.mjs ramp     "#2ecc71" "#1abc9c" "#3498db"
node scripts/color.mjs check    palette.json               # exits 1 on failure
```

`solve` finds the lightness that hits a target ratio by bisection — use it instead of grid-searching L/C/H and filtering on a validator's exit code. `ramp` checks perceptual separation between series/chart colors, including under color-vision deficiency; eyeballed chart ramps commonly fail this even for normal vision.

Validate every proposed color **in both light and dark mode** if the project has both, and check the full set: body text, muted text, placeholders, disabled states, borders, focus rings, and text on accent fills.

**Separate app-accent from content-accent.** If any color is derived from the content itself — a cover image's dominant hue, a category color, a user-chosen tag color — it is a *different system* from the app's brand accent, and the two must not composite on the same element. Layering an app-accent glow over a content-accent wash produces muddy two-hue gradients and makes the user think a color is broken. Decide explicitly which color speaks for "this is your app" and which for "this is this item," write the boundary into the plan, and check it again during implementation, because it's easy to blur under momentum while adding polish.

**Check that theme machinery is actually wired.** Finding a fully-defined `.dark` block is not evidence dark mode works — a provider may never have been mounted, making it unreachable dead code. Toggle it in the browser and capture both schemes before claiming anything about it.

## Step 6 — Generate the design direction

This is the step that's easy to shortchange, because everything before it is analysis and everything after it is documentation. This is where you actually design. Applies to **Revamp always**, and to **Improvement** whenever the execution problem is bigger than a token tweak (new layout, new component treatment, real visual rework). Skip it for **Polish** — there's no new direction to generate.

Load `/mnt/skills/public/frontend-design/SKILL.md` now if you haven't already. It has the fuller method; this section is the redesign-specific application of it.

**Generate more than one direction before committing to one.** A single direction you talk yourself into is just your first idea with justification attached. Sketch two or three genuinely different concepts — different enough that describing one wouldn't accidentally describe another — before picking. The pick itself should be defensible against the ones you didn't choose, not just against a blank page.

For each direction, work out, briefly:
- **Color** — 4–6 named values, not "a blue theme." Should trace back to what you learned in Step 0 about what it should feel like, and to the product itself, not to habit.
- **Type** — a display face and a body face, chosen for this brief. What personality does the pairing carry?
- **Layout concept** — one sentence plus a rough ASCII wireframe. This is cheap to produce and immediately shows whether an idea is actually different from the others or just a palette swap of the same layout.
- **Signature element** — the one thing this design would be remembered by. If you can't name one, the direction is probably generic.

**Actively check against the current AI-design defaults** before presenting anything: warm cream + high-contrast serif + terracotta accent; near-black + single acid-green or vermilion accent; broadsheet hairlines with zero border-radius. All three are legitimate for the right brief, but if a direction lands on one of them by default rather than because the brief specifically calls for it, that's a signal to revise, not a coincidence to ignore. Run the same brief mentally against a generic project and see if you'd land in the same place — if so, it isn't specific enough to this product yet.

**Ground every direction in the actual subject**, not a mood board floating free of it. A manga tracker's signature element should come from something true about reading manga or organizing a collection — not an abstract "clean modern" treatment that could sit on any dashboard. This is the same "what should this feel like" answer from Step 0, made concrete.

**Show the chosen direction, don't just describe it.** A paragraph of adjectives is unfalsifiable — the user can't disagree with "warmer and more modern" the way they can disagree with an actual layout. Produce something visual before writing the plan's prose: a static mockup of the highest-value screen (an HTML/React artifact, or the Visualizer for a quick comparison), or at minimum the ASCII wireframes plus the named color/type values rendered as swatches. Screenshot your own mockup and look at it critically before showing the user — the same scrutiny you'd apply to their existing UI in Step 4.

**Self-critique before presenting.** Would this direction, described without the product name, be distinguishable from a generic redesign of any similar product? If every choice is defensible on its own but the whole thing still feels like a template, cut the safest element and replace it with the riskier one you talked yourself out of. Spend the boldness in one place — the signature element — and keep the rest disciplined around it.

Once you have a direction you'd defend, that's what goes into the plan in Step 7 — not the two you didn't pick, though it's fine to mention what you rejected and why if it helps the user trust the one you kept.

## Step 7 — Write the plan

Save to `./redesign-plan.md` in the project root (or wherever the user prefers). Use the structure in `references/plan-template.md`, which has the section-by-section format and tier-specific guidance.

The plan must be **specific, evidenced, and phased**. Non-negotiables:

- **Name real screens, routes, and components.** `app/dashboard/page.tsx`, not "the dashboard area."
- **Cite screenshot evidence** for each finding, so the user can check your reasoning rather than take your word.
- **Express changes as tokens first** where the codebase has tokens. "Change `--radius` from `0.5rem` to `0.75rem`" is a one-line diff; "round the corners on all cards" is fifty.
- **Phase the work** so the user can stop early with something coherent. Phase 1 should be shippable on its own. This is what makes the plan a plan instead of a wish.
- **Flag the risky parts.** Anything touching a shared component, an accessibility regression risk, or a change users have muscle memory for. Say so, and say what you'd do instead if they don't want the risk.
- **Account for every pain point.** Each P from Step 0 maps to a finding, a phase, or an explicit "not addressed, and here's why." None may silently vanish — an unaddressed complaint is a decision, so write it as one.
- **State what you deliberately left alone**, and why. Restraint is a design decision and users notice when it's absent.

For **Revamp** (and any Improvement that went through Step 6), write up the direction you generated there: the concept, the token system (color/type/layout/signature), and *why this direction fits this product* — plus what you rejected and why, if useful. Innovative means better fitted to the actual job, which sometimes means fewer features, denser data, or a more boring layout that gets out of the way. A striking design that's worse to use is a failed redesign. Say what the direction gives up, too — every direction gives something up. Include the mockup or wireframe you produced in Step 6 rather than re-describing it in prose.

Keep the plan skimmable. Headings, short paragraphs, tables where they help. A 40-page plan doesn't get read, and an unread plan can't be argued with.

---

## Step 8 — Review with the user, then iterate

**Check the pain points before you present, not after.** Read the finished plan against the P-list from Step 0, one by one, and confirm each is genuinely resolved rather than merely mentioned nearby. This is a two-minute pass that catches the most embarrassing possible outcome: handing over a thorough, well-evidenced plan that never addresses the thing they opened with. If one isn't covered, either cover it or say in the plan why you chose not to.

Present the plan and invite disagreement specifically, not politely. "Let me know if you have feedback" gets you nothing. Ask about the parts you're least sure of: the tier fit, the direction, any library suggestion, anything you flagged risky. Ask directly whether each pain point is actually solved by what you've proposed — they're the only one who can confirm that.

Expect to be wrong about some of it — you inferred intent from a codebase, and the user has context you don't. When they push back, update the plan rather than defending it. When they say a finding is intentional, note it in the plan as a deliberate choice so it doesn't get "fixed" later.

**Flag your guesses out loud rather than deciding silently.** Where you inferred intent — that a rule extends to a case it doesn't obviously cover, that a density choice was accidental, that a constraint still applies — say so explicitly and let the user confirm or correct. A stated assumption costs one sentence; a silent one costs a rework. Conversely, when a request maps to two or more genuinely different things, ask rather than picking; guessing is only acceptable when you've said you're guessing.

Once they're happy, ask whether they want implementation next. That's a separate task and a separate conversation — this skill ends at an agreed plan.

---

## Notes on scope and extension

Currently targets **web projects (Next.js / React)**. The Playwright capture and route discovery are web-specific; everything else — the tiering, the product-understanding pass, the audit dimensions, the library policy, the plan structure — is stack-agnostic and applies unchanged elsewhere.

For a **non-Next.js web project** (Vite, CRA, Remix, Astro), skip `discover-routes.mjs` and read the router config directly; the rest works as written.

For **React Native**, the capture step needs replacing (simulator screenshots or Maestro rather than Playwright) and `references/audit-checklist.md` needs platform conventions added. Support isn't there yet — say so rather than improvising a web audit on a mobile app.

## Reference files

- `references/audit-checklist.md` — full audit dimensions. Read before Step 4.
- `references/library-landscape.md` — library candidates by category, and when a swap is actually justified. Read during Step 5.
- `references/plan-template.md` — the output structure. Read before Step 7.

## Scripts

- `scripts/discover-routes.mjs` — enumerate Next.js routes (App or Pages router) into `routes.json`.
- `scripts/capture-ui.mjs` — Playwright capture across routes, viewports, and color schemes, plus a health report.
- `scripts/color.mjs` — oklch/sRGB conversion, WCAG contrast, contrast solver, ramp separation, palette validation. Use for every color decision.

## Related skill

- `/mnt/skills/public/frontend-design/SKILL.md` — load during Step 6. Holds the fuller method for distinctive visual design (process, restraint, writing) that this skill applies specifically to redesign work.
