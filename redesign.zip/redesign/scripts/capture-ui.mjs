#!/usr/bin/env node
/**
 * capture-ui.mjs — screenshot a running app across routes, viewports, and
 * color schemes, and report on whether each page actually works.
 *
 * The health data matters as much as the images: a route that 500s or floods
 * the console isn't a design problem, and auditing a broken page wastes time.
 *
 * Usage:
 *   node capture-ui.mjs --base-url http://localhost:3000 --routes / /dashboard
 *   node capture-ui.mjs --base-url http://localhost:3000 --routes-file routes.json
 *
 * Output:
 *   <out>/<viewport>-<scheme>/<slug>.png
 *   <out>/capture-report.json
 */

import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';

const argv = process.argv.slice(2);

if (argv.includes('--help') || argv.length === 0) {
  console.log(`
capture-ui.mjs — Playwright UI capture

  --base-url <url>        Required. e.g. http://localhost:3000
  --routes <a> <b> ...    Space-separated route paths
  --routes-file <file>    JSON file with {"routes": ["/", "/x"]} or a bare array
  --out <dir>             Output dir (default: ./redesign-audit/screenshots)
  --viewports <list>      mobile,tablet,desktop,wide (default: mobile,desktop)
  --color-scheme <list>   light,dark (default: light)
  --full-page             Capture full scrollable page, not just the fold
  --auth-storage <file>   Playwright storageState JSON for logged-in capture
  --wait <ms>             Extra settle time per page (default: 600)
  --timeout <ms>          Per-page navigation timeout (default: 20000)
  --help

Viewport presets: mobile 390x844, tablet 768x1024, desktop 1440x900, wide 1920x1080
`);
  process.exit(0);
}

function getFlag(name, fallback = null) {
  const i = argv.indexOf(`--${name}`);
  if (i === -1) return fallback;
  const next = argv[i + 1];
  return next && !next.startsWith('--') ? next : true;
}

function getList(name) {
  const i = argv.indexOf(`--${name}`);
  if (i === -1) return [];
  const out = [];
  for (let j = i + 1; j < argv.length && !argv[j].startsWith('--'); j++) out.push(argv[j]);
  return out;
}

const VIEWPORTS = {
  mobile: { width: 390, height: 844, isMobile: true },
  tablet: { width: 768, height: 1024, isMobile: false },
  desktop: { width: 1440, height: 900, isMobile: false },
  wide: { width: 1920, height: 1080, isMobile: false },
};

const baseUrl = String(getFlag('base-url', '')).replace(/\/$/, '');
if (!baseUrl) {
  console.error('Missing --base-url. Run with --help for usage.');
  process.exit(1);
}

const outDir = String(getFlag('out', './redesign-audit/screenshots'));
const fullPage = argv.includes('--full-page');
const authStorage = getFlag('auth-storage');
const settle = Number(getFlag('wait', 600));
const timeout = Number(getFlag('timeout', 20000));

const viewportNames = String(getFlag('viewports', 'mobile,desktop')).split(',').map((s) => s.trim());
const schemes = String(getFlag('color-scheme', 'light')).split(',').map((s) => s.trim());

for (const v of viewportNames) {
  if (!VIEWPORTS[v]) {
    console.error(`Unknown viewport "${v}". Valid: ${Object.keys(VIEWPORTS).join(', ')}`);
    process.exit(1);
  }
}

let routes = getList('routes');
const routesFile = getFlag('routes-file');
if (routesFile && routesFile !== true) {
  const parsed = JSON.parse(await readFile(String(routesFile), 'utf8'));
  const fromFile = Array.isArray(parsed) ? parsed : parsed.routes;
  if (!Array.isArray(fromFile)) {
    console.error(`${routesFile} must be an array or an object with a "routes" array.`);
    process.exit(1);
  }
  routes = [...routes, ...fromFile];
}
routes = [...new Set(routes.map((r) => (r.startsWith('/') ? r : `/${r}`)))];

if (routes.length === 0) {
  console.error('No routes given. Use --routes or --routes-file.');
  process.exit(1);
}

let chromium;
try {
  ({ chromium } = await import('playwright'));
} catch {
  console.error(
    'Playwright is not installed in this project.\n\n' +
    'Install it with:\n' +
    '  npm i -D playwright && npx playwright install chromium\n\n' +
    'Or run this script standalone:\n' +
    '  npx --yes playwright@latest install chromium\n'
  );
  process.exit(1);
}

const slug = (route) => {
  const s = route.replace(/^\//, '').replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-|-$/g, '');
  return s || 'root';
};

const browser = await chromium.launch();
const report = {
  base_url: baseUrl,
  captured_at: new Date().toISOString(),
  viewports: viewportNames,
  color_schemes: schemes,
  full_page: fullPage,
  results: [],
};

for (const viewportName of viewportNames) {
  const { width, height, isMobile } = VIEWPORTS[viewportName];

  for (const scheme of schemes) {
    const dirName = `${viewportName}-${scheme}`;
    const dir = join(outDir, dirName);
    await mkdir(dir, { recursive: true });

    const context = await browser.newContext({
      viewport: { width, height },
      deviceScaleFactor: 2,
      isMobile,
      hasTouch: isMobile,
      colorScheme: scheme,
      ...(authStorage && authStorage !== true ? { storageState: String(authStorage) } : {}),
    });

    for (const route of routes) {
      const page = await context.newPage();
      const consoleErrors = [];
      const failedRequests = [];

      page.on('console', (msg) => {
        if (msg.type() === 'error') consoleErrors.push(msg.text().slice(0, 300));
      });
      page.on('pageerror', (err) => consoleErrors.push(`[uncaught] ${String(err).slice(0, 300)}`));
      page.on('requestfailed', (req) => {
        failedRequests.push({ url: req.url().slice(0, 200), reason: req.failure()?.errorText });
      });

      const entry = {
        route,
        viewport: viewportName,
        color_scheme: scheme,
        screenshot: null,
        status: null,
        final_url: null,
        redirected: false,
        title: null,
        console_errors: [],
        failed_requests: [],
        error: null,
      };

      const target = `${baseUrl}${route === '/' ? '/' : route}`;

      try {
        const response = await page.goto(target, { waitUntil: 'networkidle', timeout });
        entry.status = response ? response.status() : null;
        await page.waitForTimeout(settle);

        entry.final_url = page.url();
        entry.redirected = new URL(entry.final_url).pathname !== new URL(target).pathname;
        entry.title = await page.title().catch(() => null);

        const file = join(dir, `${slug(route)}.png`);
        await page.screenshot({ path: file, fullPage });
        entry.screenshot = file;
      } catch (err) {
        entry.error = String(err.message || err).split('\n')[0].slice(0, 300);
      }

      entry.console_errors = consoleErrors.slice(0, 10);
      entry.failed_requests = failedRequests.slice(0, 10);
      report.results.push(entry);

      const mark = entry.error ? 'FAIL' : entry.status && entry.status >= 400 ? `HTTP ${entry.status}` : 'ok';
      const notes = [
        entry.redirected ? `-> ${new URL(entry.final_url).pathname}` : '',
        entry.console_errors.length ? `${entry.console_errors.length} console err` : '',
      ].filter(Boolean).join(' ');
      console.error(`[${mark}] ${dirName} ${route} ${notes}`);

      await page.close();
    }

    await context.close();
  }
}

await browser.close();

const healthy = report.results.filter((r) => !r.error && r.status && r.status < 400);
const redirected = report.results.filter((r) => r.redirected);
report.summary = {
  total: report.results.length,
  ok: healthy.length,
  failed: report.results.length - healthy.length,
  redirected: redirected.length,
  routes_with_console_errors: [...new Set(report.results.filter((r) => r.console_errors.length).map((r) => r.route))],
  routes_failing: [...new Set(report.results.filter((r) => r.error || (r.status && r.status >= 400)).map((r) => r.route))],
};

await mkdir(outDir, { recursive: true });
const reportPath = join(outDir, 'capture-report.json');
await writeFile(reportPath, JSON.stringify(report, null, 2));

console.error(`\n${report.summary.ok}/${report.summary.total} captures ok. Report: ${reportPath}`);
if (report.summary.redirected > 0) {
  console.error(
    `${report.summary.redirected} capture(s) redirected — likely an auth wall. ` +
    `Pass --auth-storage to capture logged-in pages.`
  );
}
if (report.summary.routes_failing.length) {
  console.error(`Failing routes: ${report.summary.routes_failing.join(', ')}`);
}
