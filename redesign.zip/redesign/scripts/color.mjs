#!/usr/bin/env node
/**
 * color.mjs — canonical color math for redesign work.
 *
 * Exists because hand-rolling oklch -> linear sRGB -> WCAG contrast in
 * throwaway scripts is the single most-repeated task in a redesign, and the
 * most likely to be silently wrong. The classic failure: feeding gamma-encoded
 * sRGB straight into the relative-luminance formula without linearizing it.
 * That produces plausible-looking numbers that are wrong, which is worse than
 * numbers that are obviously wrong. This file linearizes correctly. Use it
 * instead of rederiving the math.
 *
 * Never eyeball contrast. It will fail at least once, and you want to find out
 * before the user does.
 *
 * Commands:
 *   convert   <color>...                  oklch <-> hex <-> rgb, + gamut check
 *   contrast  <fg> <bg> [...]             WCAG ratio + AA/AAA verdicts
 *   solve     <bg> <target> [--hue H --chroma C]   find the L that hits a ratio
 *   ramp      <c1> <c2> <c3>...           perceptual separation between colors
 *   check     <palette.json>              validate a whole palette at once
 *
 * Color syntax accepted anywhere a <color> is expected:
 *   #1a2b3c   #abc   rgb(26,43,60)   oklch(0.62 0.19 27)   oklch(62% .19 27)
 *
 * All commands accept --json for machine-readable output.
 */

// ---------------------------------------------------------------------------
// sRGB transfer function
// ---------------------------------------------------------------------------

const srgbToLinear = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
const linearToSrgb = (c) => (c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055);

// ---------------------------------------------------------------------------
// Oklab / Oklch  (Björn Ottosson)
// ---------------------------------------------------------------------------

function linearRgbToOklab([r, g, b]) {
  const l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b;
  const m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b;
  const s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b;
  const l_ = Math.cbrt(l), m_ = Math.cbrt(m), s_ = Math.cbrt(s);
  return [
    0.2104542553 * l_ + 0.793617785 * m_ - 0.0040720468 * s_,
    1.9779984951 * l_ - 2.428592205 * m_ + 0.4505937099 * s_,
    0.0259040371 * l_ + 0.7827717662 * m_ - 0.808675766 * s_,
  ];
}

function oklabToLinearRgb([L, a, b]) {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3;
  return [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  ];
}

const oklabToOklch = ([L, a, b]) => {
  const C = Math.hypot(a, b);
  let h = (Math.atan2(b, a) * 180) / Math.PI;
  if (h < 0) h += 360;
  return [L, C, C < 1e-6 ? 0 : h];
};

const oklchToOklab = ([L, C, h]) => {
  const rad = (h * Math.PI) / 180;
  return [L, C * Math.cos(rad), C * Math.sin(rad)];
};

// ---------------------------------------------------------------------------
// Parsing / formatting
// ---------------------------------------------------------------------------

function parseColor(input) {
  const s = String(input).trim().toLowerCase();

  let m = s.match(/^#?([0-9a-f]{3}|[0-9a-f]{6})$/);
  if (m) {
    let hex = m[1];
    if (hex.length === 3) hex = hex.split('').map((c) => c + c).join('');
    return {
      srgb: [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255),
      source: 'hex',
    };
  }

  m = s.match(/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/);
  if (m) return { srgb: m.slice(1, 4).map((v) => Number(v) / 255), source: 'rgb' };

  m = s.match(/^oklch\(\s*([\d.]+%?)\s+([\d.]+%?)\s+([-\d.]+)/);
  if (m) {
    const L = m[1].endsWith('%') ? parseFloat(m[1]) / 100 : Number(m[1]);
    const C = m[2].endsWith('%') ? (parseFloat(m[2]) / 100) * 0.4 : Number(m[2]);
    const h = Number(m[3]);
    const linear = oklabToLinearRgb(oklchToOklab([L, C, h]));
    return { srgb: linear.map(linearToSrgb), oklch: [L, C, h], source: 'oklch' };
  }

  throw new Error(`Cannot parse color: "${input}" (want hex, rgb(), or oklch())`);
}

const clamp01 = (v) => Math.min(1, Math.max(0, v));
const toHex = (srgb) =>
  '#' + srgb.map((c) => Math.round(clamp01(c) * 255).toString(16).padStart(2, '0')).join('');

function describe(input) {
  const { srgb, oklch: given } = parseColor(input);
  const linear = srgb.map(srgbToLinear);
  const oklch = given ?? oklabToOklch(linearRgbToOklab(linear));
  // Out of sRGB gamut if any channel escaped [0,1] before clamping.
  const inGamut = srgb.every((c) => c >= -0.0001 && c <= 1.0001);
  return {
    input: String(input),
    hex: toHex(srgb),
    rgb: srgb.map((c) => Math.round(clamp01(c) * 255)),
    oklch: [round(oklch[0], 4), round(oklch[1], 4), round(oklch[2], 2)],
    oklch_css: `oklch(${round(oklch[0], 4)} ${round(oklch[1], 4)} ${round(oklch[2], 2)})`,
    luminance: round(relativeLuminance(srgb), 5),
    in_srgb_gamut: inGamut,
  };
}

const round = (v, n) => Number(v.toFixed(n));

// ---------------------------------------------------------------------------
// WCAG
// ---------------------------------------------------------------------------

function relativeLuminance(srgb) {
  const [r, g, b] = srgb.map((c) => srgbToLinear(clamp01(c)));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function contrastRatio(a, b) {
  const l1 = relativeLuminance(parseColor(a).srgb);
  const l2 = relativeLuminance(parseColor(b).srgb);
  const [hi, lo] = l1 > l2 ? [l1, l2] : [l2, l1];
  return (hi + 0.05) / (lo + 0.05);
}

function verdicts(ratio) {
  return {
    normal_text_AA: ratio >= 4.5,
    normal_text_AAA: ratio >= 7,
    large_text_AA: ratio >= 3,
    large_text_AAA: ratio >= 4.5,
    ui_and_graphics: ratio >= 3,
  };
}

// ---------------------------------------------------------------------------
// Perceptual distance (Oklab Euclidean — good enough for ramp separation)
// ---------------------------------------------------------------------------

function deltaOk(a, b) {
  const la = linearRgbToOklab(parseColor(a).srgb.map(srgbToLinear));
  const lb = linearRgbToOklab(parseColor(b).srgb.map(srgbToLinear));
  return Math.hypot(la[0] - lb[0], la[1] - lb[1], la[2] - lb[2]);
}

/** Crude dichromat simulation (Viénot/Brettel-style) for ramp sanity checks. */
function simulateCVD(color, type) {
  const [r, g, b] = parseColor(color).srgb.map(srgbToLinear);
  const M = {
    protanopia: [[0.1121, 0.8853, -0.0005], [0.1127, 0.8897, -0.0001], [0.0045, 0.0, 1.0]],
    deuteranopia: [[0.292, 0.7054, -0.0003], [0.2934, 0.7089, 0.0], [-0.0209, 0.0286, 1.0]],
    tritanopia: [[1.0, 0.1502, -0.1387], [0.0, 0.8172, 0.1828], [0.0, 0.1273, 0.8727]],
  }[type];
  const out = M.map((row) => row[0] * r + row[1] * g + row[2] * b);
  return toHex(out.map(linearToSrgb));
}

// ---------------------------------------------------------------------------
// Solver — bisection, not brute-force grid search
// ---------------------------------------------------------------------------

/**
 * Find the Oklch lightness that hits a target contrast against `bg`, holding
 * hue and chroma. Bisection: ~20 iterations, exact, explainable. Beats looping
 * over an L/C/H grid and filtering on a validator's exit code.
 */
function solveLightness(bg, target, hue, chroma) {
  const bgLum = relativeLuminance(parseColor(bg).srgb);
  const ratioAt = (L) => {
    const srgb = oklabToLinearRgb(oklchToOklab([L, chroma, hue])).map(linearToSrgb);
    const lum = relativeLuminance(srgb);
    const [hi, lo] = lum > bgLum ? [lum, bgLum] : [bgLum, lum];
    return { ratio: (hi + 0.05) / (lo + 0.05), srgb, lighter: lum > bgLum };
  };

  const results = [];
  // Search downward (darker than bg) and upward (lighter than bg) separately.
  for (const [lo0, hi0, label] of [[0, 1, 'darker'], [0, 1, 'lighter']]) {
    let lo = lo0, hi = hi0;
    const wantLighter = label === 'lighter';
    // Only meaningful if that direction can actually reach the target.
    const extreme = ratioAt(wantLighter ? 1 : 0);
    if (extreme.ratio < target || extreme.lighter !== wantLighter) continue;

    for (let i = 0; i < 40; i++) {
      const mid = (lo + hi) / 2;
      const { ratio, lighter } = ratioAt(mid);
      const meets = ratio >= target && lighter === wantLighter;
      if (wantLighter) { if (meets) hi = mid; else lo = mid; }
      else { if (meets) lo = mid; else hi = mid; }
    }
    const L = wantLighter ? hi : lo;
    const r = ratioAt(L);
    if (r.ratio >= target - 0.01 && r.lighter === wantLighter) {
      const inGamut = r.srgb.every((c) => c >= -0.0001 && c <= 1.0001);
      results.push({
        direction: label,
        L: round(L, 4),
        oklch_css: `oklch(${round(L, 4)} ${chroma} ${hue})`,
        hex: toHex(r.srgb),
        ratio: round(r.ratio, 2),
        in_srgb_gamut: inGamut,
      });
    }
  }
  return results;
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

const argv = process.argv.slice(2);
const cmd = argv[0];
const json = argv.includes('--json');
const rest = argv.slice(1).filter((a) => !a.startsWith('--'));
const opt = (name, fallback) => {
  const i = argv.indexOf(`--${name}`);
  return i === -1 ? fallback : argv[i + 1];
};

const out = (obj, human) => {
  if (json) console.log(JSON.stringify(obj, null, 2));
  else human();
};

const pct = (b) => (b ? 'PASS' : 'FAIL');

try {
  switch (cmd) {
    case 'convert': {
      const data = rest.map(describe);
      out(data, () => {
        for (const d of data) {
          console.log(`${d.input}`);
          console.log(`  hex        ${d.hex}`);
          console.log(`  rgb        ${d.rgb.join(', ')}`);
          console.log(`  oklch      ${d.oklch_css}`);
          console.log(`  luminance  ${d.luminance}`);
          if (!d.in_srgb_gamut) console.log(`  ⚠ OUT OF sRGB GAMUT — will be clipped by browsers`);
          console.log();
        }
      });
      break;
    }

    case 'contrast': {
      if (rest.length < 2 || rest.length % 2 !== 0) {
        throw new Error('contrast needs pairs: <fg> <bg> [<fg> <bg> ...]');
      }
      const pairs = [];
      for (let i = 0; i < rest.length; i += 2) {
        const ratio = contrastRatio(rest[i], rest[i + 1]);
        pairs.push({
          fg: describe(rest[i]).hex,
          bg: describe(rest[i + 1]).hex,
          ratio: round(ratio, 2),
          ...verdicts(ratio),
        });
      }
      out(pairs, () => {
        for (const p of pairs) {
          console.log(`${p.fg} on ${p.bg} → ${p.ratio}:1`);
          console.log(`  body text (AA 4.5)      ${pct(p.normal_text_AA)}`);
          console.log(`  body text (AAA 7)       ${pct(p.normal_text_AAA)}`);
          console.log(`  large text (AA 3)       ${pct(p.large_text_AA)}`);
          console.log(`  UI / icons / borders    ${pct(p.ui_and_graphics)}`);
          console.log();
        }
      });
      break;
    }

    case 'solve': {
      const [bg, targetRaw] = rest;
      if (!bg || !targetRaw) throw new Error('solve needs: <bg> <target-ratio> [--hue H --chroma C]');
      const target = Number(targetRaw);
      const hue = Number(opt('hue', 0));
      const chroma = Number(opt('chroma', 0));
      const results = solveLightness(bg, target, hue, chroma);
      out({ bg: describe(bg).hex, target, hue, chroma, results }, () => {
        console.log(`Colors at hue ${hue}, chroma ${chroma} hitting ${target}:1 on ${describe(bg).hex}:\n`);
        if (!results.length) {
          console.log(`  No solution. Reduce chroma, change hue, or lower the target.`);
        }
        for (const r of results) {
          console.log(`  ${r.direction.padEnd(8)} ${r.oklch_css}  ${r.hex}  ${r.ratio}:1${r.in_srgb_gamut ? '' : '  ⚠ out of gamut'}`);
        }
      });
      break;
    }

    case 'ramp': {
      if (rest.length < 2) throw new Error('ramp needs 2+ colors');
      const pairs = [];
      for (let i = 0; i < rest.length - 1; i++) {
        const d = deltaOk(rest[i], rest[i + 1]);
        pairs.push({
          a: describe(rest[i]).hex,
          b: describe(rest[i + 1]).hex,
          delta_ok: round(d, 4),
          distinguishable: d >= 0.08,
        });
      }
      const cvd = ['protanopia', 'deuteranopia', 'tritanopia'].map((type) => {
        const sims = rest.map((c) => simulateCVD(c, type));
        const mins = [];
        for (let i = 0; i < sims.length - 1; i++) mins.push(deltaOk(sims[i], sims[i + 1]));
        return { type, simulated: sims, min_delta: round(Math.min(...mins), 4), risky: Math.min(...mins) < 0.06 };
      });
      out({ adjacent: pairs, cvd }, () => {
        console.log('Adjacent separation (Oklab ΔE, ≥0.08 is comfortably distinct):\n');
        for (const p of pairs) {
          console.log(`  ${p.a} → ${p.b}   ΔE ${p.delta_ok}  ${p.distinguishable ? 'ok' : '⚠ TOO CLOSE'}`);
        }
        console.log('\nColor-vision-deficiency check:\n');
        for (const c of cvd) {
          console.log(`  ${c.type.padEnd(14)} min ΔE ${c.min_delta}  ${c.risky ? '⚠ colors merge — add a non-color cue' : 'ok'}`);
        }
      });
      break;
    }

    case 'check': {
      const file = rest[0];
      if (!file) throw new Error('check needs a palette JSON file');
      const { readFile } = await import('node:fs/promises');
      const palette = JSON.parse(await readFile(file, 'utf8'));
      /* Expected shape:
         { "backgrounds": { "surface": "#fff" },
           "pairs": [ { "name": "muted text", "fg": "...", "bg": "...", "min": 4.5 } ] } */
      const rows = (palette.pairs ?? []).map((p) => {
        const ratio = contrastRatio(p.fg, p.bg);
        const min = p.min ?? 4.5;
        return { ...p, ratio: round(ratio, 2), min, pass: ratio >= min };
      });
      const failures = rows.filter((r) => !r.pass);
      out({ rows, failures: failures.length }, () => {
        for (const r of rows) {
          console.log(`  ${r.pass ? 'PASS' : 'FAIL'}  ${String(r.ratio).padStart(5)}:1  (need ${r.min})  ${r.name}`);
        }
        console.log(`\n${rows.length - failures.length}/${rows.length} pass.`);
      });
      if (failures.length) process.exitCode = 1;
      break;
    }

    default:
      console.log(`
color.mjs — canonical color math for redesign work

  convert  <color>...              oklch <-> hex <-> rgb, luminance, gamut
  contrast <fg> <bg> [...]         WCAG ratio + AA/AAA verdicts
  solve    <bg> <ratio> --hue H --chroma C
                                   find the L that hits a target contrast
  ramp     <c1> <c2> ...           separation between series/chart colors
  check    <palette.json>          validate a whole palette (exit 1 on failure)

  --json                           machine-readable output

Colors: #1a2b3c | #abc | rgb(26,43,60) | oklch(0.62 0.19 27)
`);
  }
} catch (err) {
  console.error(`Error: ${err.message}`);
  process.exit(1);
}
