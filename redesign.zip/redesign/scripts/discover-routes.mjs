#!/usr/bin/env node
/**
 * discover-routes.mjs — enumerate routes in a Next.js project.
 *
 * Handles App Router and Pages Router, including the conventions that make
 * naive globbing wrong: route groups, private folders, dynamic and catch-all
 * segments, parallel/intercepting routes, and colocated non-route files.
 *
 * Usage:
 *   node discover-routes.mjs --project . [--out routes.json] [--include-dynamic]
 *
 * Dynamic routes are excluded by default because you can't visit /posts/[id]
 * without a real id. They're still listed under `dynamic` in the output so you
 * can substitute real ids from the database and add them manually.
 */

import { readdir, stat, writeFile } from 'node:fs/promises';
import { join, relative, sep, basename, extname } from 'node:path';

const args = process.argv.slice(2);
const flag = (name, fallback = null) => {
  const i = args.indexOf(`--${name}`);
  if (i === -1) return fallback;
  const next = args[i + 1];
  return next && !next.startsWith('--') ? next : true;
};

if (args.includes('--help')) {
  console.log(`
discover-routes.mjs — enumerate Next.js routes

  --project <dir>      Project root (default: .)
  --out <file>         Write JSON here (default: stdout only)
  --include-dynamic    Include [param] routes in the main list
  --help
`);
  process.exit(0);
}

const projectRoot = String(flag('project', '.'));
const outFile = flag('out');
const includeDynamic = args.includes('--include-dynamic');

const PAGE_BASENAMES = new Set(['page', 'route']);
const PAGE_EXTS = new Set(['.tsx', '.ts', '.jsx', '.js', '.mdx']);
const SKIP_DIRS = new Set(['node_modules', '.next', '.git', 'dist', 'build', 'coverage', '.turbo']);

async function exists(p) {
  try { await stat(p); return true; } catch { return false; }
}

async function findRoot() {
  const candidates = [
    ['app', join(projectRoot, 'app')],
    ['app', join(projectRoot, 'src', 'app')],
    ['pages', join(projectRoot, 'pages')],
    ['pages', join(projectRoot, 'src', 'pages')],
  ];
  const found = [];
  for (const [kind, dir] of candidates) {
    if (await exists(dir)) found.push({ kind, dir });
  }
  return found;
}

async function walk(dir, out = []) {
  let entries;
  try { entries = await readdir(dir, { withFileTypes: true }); } catch { return out; }
  for (const entry of entries) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      await walk(full, out);
    } else {
      out.push(full);
    }
  }
  return out;
}

/** App Router: a route exists where there's a page.* (route.* = API, tracked separately). */
function appRouteFromFile(appDir, file) {
  const ext = extname(file);
  const base = basename(file, ext);
  if (!PAGE_EXTS.has(ext) || !PAGE_BASENAMES.has(base)) return null;

  const segments = relative(appDir, file).split(sep).slice(0, -1);

  // Private folders (_foo) are never routable.
  if (segments.some((s) => s.startsWith('_'))) return null;
  // Parallel (@slot) and intercepting ((.)foo) routes aren't directly navigable.
  if (segments.some((s) => s.startsWith('@'))) return null;
  if (segments.some((s) => /^\(\.{1,3}\)/.test(s) || s.startsWith('(..)'))) return null;

  // Route groups (foo) contribute no URL segment.
  const urlSegments = segments.filter((s) => !(s.startsWith('(') && s.endsWith(')')));

  return {
    path: '/' + urlSegments.join('/'),
    kind: base === 'route' ? 'api' : 'page',
    file: relative(projectRoot, file),
    dynamic: urlSegments.some((s) => s.includes('[')),
  };
}

/** Pages Router: every file under pages/ is a route, minus _app/_document/api specials. */
function pagesRouteFromFile(pagesDir, file) {
  const ext = extname(file);
  const base = basename(file, ext);
  if (!PAGE_EXTS.has(ext)) return null;
  if (base.startsWith('_')) return null;

  const segments = relative(pagesDir, file).split(sep);
  const isApi = segments[0] === 'api';
  const last = segments.pop();
  const lastBase = basename(last, extname(last));
  if (lastBase !== 'index') segments.push(lastBase);

  return {
    path: '/' + segments.join('/'),
    kind: isApi ? 'api' : 'page',
    file: relative(projectRoot, file),
    dynamic: segments.some((s) => s.includes('[')),
  };
}

const roots = await findRoot();
if (roots.length === 0) {
  console.error(
    `No app/ or pages/ directory found under "${projectRoot}".\n` +
    `If this isn't a Next.js project, read the router config directly instead.`
  );
  process.exit(1);
}

const all = [];
for (const { kind, dir } of roots) {
  const files = await walk(dir);
  for (const file of files) {
    const route = kind === 'app' ? appRouteFromFile(dir, file) : pagesRouteFromFile(dir, file);
    if (route) all.push({ ...route, router: kind });
  }
}

const byPath = new Map();
for (const r of all) if (!byPath.has(r.path + r.kind)) byPath.set(r.path + r.kind, r);
const unique = [...byPath.values()].sort((a, b) => a.path.localeCompare(b.path));

const pages = unique.filter((r) => r.kind === 'page');
const staticPages = pages.filter((r) => !r.dynamic).map((r) => r.path);
const dynamicPages = pages.filter((r) => r.dynamic);
const apiRoutes = unique.filter((r) => r.kind === 'api').map((r) => r.path);

const result = {
  routers: [...new Set(roots.map((r) => r.kind))],
  routes: includeDynamic ? pages.map((r) => r.path) : staticPages,
  dynamic: dynamicPages.map((r) => ({ path: r.path, file: r.file })),
  api: apiRoutes,
  detail: pages,
};

const json = JSON.stringify(result, null, 2);
if (outFile && outFile !== true) {
  await writeFile(String(outFile), json);
  console.error(`Wrote ${result.routes.length} routes to ${outFile}`);
}
console.log(json);

if (dynamicPages.length) {
  console.error(
    `\n${dynamicPages.length} dynamic route(s) excluded — substitute real ids to capture them:\n` +
    dynamicPages.map((r) => `  ${r.path}`).join('\n')
  );
}
